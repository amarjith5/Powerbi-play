UNIVERSAL STUDIOS JAPAN — POWER BI EDITABLE HEADER KIT
Canvas: 1920 × 120 px

WHAT IS EDITABLE
- 01 logo: separate transparent PNG (exact logo artwork supplied by you; raster asset, movable/resizable but not editable letter-by-letter).
- 02 scenery: separate scenic strip image.
- 03 background: navy background with scenery strip; use this as the base image.
- 04 gold accents: separate SVG vector, can be recolored/edited in an SVG editor.
- 05/06/07 icons: separate SVG vector assets.
- Timestamp and labels: create as native Power BI text boxes; use DAX below for the timestamp.
- Refresh and Home: create native Power BI buttons and assign actions/bookmarks as appropriate.

IMPORTANT POWER BI LIMITATION
Power BI treats a PNG or SVG placed in an Image visual as one image object. It does not expose the internal parts of that image as individually editable shapes. For a genuinely editable report header, layer the background image, logo image, SVG decorations/icons, text boxes, and native buttons as separate report objects. The scenic photo and supplied logo artwork remain image assets; text, buttons, and layout remain independently editable.

SUGGESTED PLACEMENT (1920 × 120 canvas)
- Background: X=0, Y=0, W=1920, H=120
- Logo: X=45, Y=4, W=390, H=112 (maintain aspect ratio)
- Gold accent SVG: X=0, Y=0, W=1920, H=120
- Divider 1: X=490, Y=18, H=84
- Status panel: X=1500, Y=27, W=290, H=64 (native rounded rectangle + text + clock SVG)
- Refresh button: X=1810, Y=24, W=64, H=72
- Home button: X=1880, Y=24, W=64, H=72

DAX MEASURE (refresh timestamp)
Last Refreshed =
"Last refreshed: " & FORMAT(NOW(), "dd MMM yyyy, hh:mm AM/PM")

Note: NOW() updates when the semantic model is refreshed/evaluated; it is not a live timer. For a reliable dataset refresh timestamp, add a Power Query parameter/query that captures DateTime.LocalNow() during refresh and expose it as a one-row table/measure.

IMPORT STEPS
1. Set the report page to a custom size with width 1920 and height as needed.
2. Add 03_background_scenery_only_1920x120.png as the bottom image.
3. Add the logo PNG above it and preserve aspect ratio.
4. Add the gold SVG overlay and individual SVG icons as separate image objects.
5. Add native text boxes for title and timestamp; add native buttons for Refresh/Home.
6. Use the Selection pane to rename and lock the background layers.
